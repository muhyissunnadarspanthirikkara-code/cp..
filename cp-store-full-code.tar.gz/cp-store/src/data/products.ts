export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice: number;
  category: "Electronics" | "Fashion & Accessories" | "Footwear" | "Mobile Gadgets";
  subCategory: string;
  image: string;
  description: string;
}

export const products: Product[] = [

  // ── ELECTRONICS: EARPODS (10 models) ──
  { id: "ep1",  name: "CP Pro Wireless Earpods",        price: 299,  originalPrice: 599,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "True wireless earpods with active noise cancellation and 24hr battery life." },
  { id: "ep2",  name: "CP Bass+ Earpods",               price: 349,  originalPrice: 699,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Deep bass earpods with transparent mode and IPX5 water resistance." },
  { id: "ep3",  name: "CP Sport Earpods",               price: 279,  originalPrice: 549,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Secure-fit sport earpods for workouts, sweat-proof design." },
  { id: "ep4",  name: "CP Mini Earpods",                price: 199,  originalPrice: 399,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Compact mini earpods with crystal-clear audio and touch controls." },
  { id: "ep5",  name: "CP Elite TWS Earpods",           price: 499,  originalPrice: 999,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Premium TWS earpods with LDAC codec support and 30hr total battery." },
  { id: "ep6",  name: "CP Lite Earpods",                price: 179,  originalPrice: 350,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Lightweight earpods with auto-connect and low latency gaming mode." },
  { id: "ep7",  name: "CP Neckband Earpods",            price: 399,  originalPrice: 799,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Neckband style wireless earpods with magnetic snap and 20hr battery." },
  { id: "ep8",  name: "CP Boom Earpods",                price: 329,  originalPrice: 649,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Extra bass earpods with dual EQ modes and fast 15-min charge." },
  { id: "ep9",  name: "CP Gamer Earpods",               price: 449,  originalPrice: 899,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Low-latency gaming earpods with RGB charging case." },
  { id: "ep10", name: "CP Kids Earpods",                price: 249,  originalPrice: 499,  category: "Electronics", subCategory: "Earpods",       image: "/images/earpods.png",   description: "Volume-limited safe earpods for kids with colorful design." },

  // ── ELECTRONICS: EARPHONES (10 models) ──
  { id: "eh1",  name: "CP Bass Wired Earphones",        price: 149,  originalPrice: 299,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "Deep bass wired earphones with tangle-free flat cable and mic." },
  { id: "eh2",  name: "CP Pro Earphones",               price: 199,  originalPrice: 399,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "Hi-fi wired earphones with 10mm dynamic driver and volume control." },
  { id: "eh3",  name: "CP Sport In-Ear",                price: 179,  originalPrice: 349,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "Sports in-ear earphones with ear hook and sweat-proof build." },
  { id: "eh4",  name: "CP Metal Earphones",             price: 249,  originalPrice: 499,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "Metal shell earphones with balanced armature driver, audiophile grade." },
  { id: "eh5",  name: "CP Dual Driver Earphones",       price: 299,  originalPrice: 599,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "Dual driver earphones with deep bass and clear highs." },
  { id: "eh6",  name: "CP Stereo Earphones",            price: 99,   originalPrice: 199,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "Budget stereo earphones with in-line mic for calls." },
  { id: "eh7",  name: "CP HD Voice Earphones",          price: 169,  originalPrice: 329,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "HD voice earphones optimized for call clarity and noise reduction." },
  { id: "eh8",  name: "CP 3.5mm L-Shaped Earphones",   price: 139,  originalPrice: 279,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "L-shaped plug earphones, tangle-resistant, compatible with all phones." },
  { id: "eh9",  name: "CP Type-C Earphones",            price: 219,  originalPrice: 439,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "USB Type-C digital earphones with DAC chip for enhanced audio." },
  { id: "eh10", name: "CP Neon Earphones",              price: 159,  originalPrice: 319,  category: "Electronics", subCategory: "Earphones",     image: "/images/earpods.png",   description: "Stylish neon-cable earphones with punchy bass and clear mids." },

  // ── ELECTRONICS: HEADSETS (10 models) ──
  { id: "hs1",  name: "CP Gaming Headset",              price: 499,  originalPrice: 999,  category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Over-ear gaming headset with 7.1 surround sound and LED lighting." },
  { id: "hs2",  name: "CP Studio Headset",              price: 699,  originalPrice: 1399, category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Studio-quality on-ear headset with foldable design and 32-ohm drivers." },
  { id: "hs3",  name: "CP Wireless Headset",            price: 799,  originalPrice: 1599, category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Bluetooth 5.0 wireless headset with 30hr battery and ANC." },
  { id: "hs4",  name: "CP Office Headset",              price: 399,  originalPrice: 799,  category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Single-ear office headset with detachable boom mic for calls." },
  { id: "hs5",  name: "CP Bass Headset",                price: 449,  originalPrice: 899,  category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Extra bass over-ear headset with soft cushion earpads." },
  { id: "hs6",  name: "CP DJ Headset",                  price: 599,  originalPrice: 1199, category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Professional DJ-style headset with 180° swivel cups and deep bass." },
  { id: "hs7",  name: "CP Kids Headset",                price: 299,  originalPrice: 599,  category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Colorful kids headset with volume limiting and durable build." },
  { id: "hs8",  name: "CP Sport Headset",               price: 349,  originalPrice: 699,  category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Sweat-resistant sport headset with ear hooks for active use." },
  { id: "hs9",  name: "CP Noise Cancelling Headset",    price: 999,  originalPrice: 1999, category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Active noise cancelling headset ideal for travel and focus work." },
  { id: "hs10", name: "CP Foldable Headset",            price: 379,  originalPrice: 759,  category: "Electronics", subCategory: "Headsets",      image: "/images/earpods.png",   description: "Compact foldable headset that fits easily in your bag." },

  // ── ELECTRONICS: MINI SPEAKERS (10 models) ──
  { id: "sp1",  name: "CP Mini Cube Speaker",           price: 499,  originalPrice: 999,  category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "Compact cube-shaped Bluetooth speaker with 360° sound." },
  { id: "sp2",  name: "CP Bass Boom Speaker",           price: 699,  originalPrice: 1399, category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "Portable speaker with thumping bass and 12hr battery." },
  { id: "sp3",  name: "CP Waterproof Speaker",          price: 799,  originalPrice: 1599, category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "IPX7 waterproof Bluetooth speaker for outdoor and shower use." },
  { id: "sp4",  name: "CP Pocket Speaker",              price: 299,  originalPrice: 599,  category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "Ultra-portable pocket speaker with carabiner clip." },
  { id: "sp5",  name: "CP LED Speaker",                 price: 599,  originalPrice: 1199, category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "Bluetooth speaker with colorful LED light show and deep bass." },
  { id: "sp6",  name: "CP Stereo Pair Speaker",         price: 899,  originalPrice: 1799, category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "True stereo pairable mini speakers for 360° room-filling sound." },
  { id: "sp7",  name: "CP Tower Speaker",               price: 749,  originalPrice: 1499, category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "Tall cylinder tower speaker with FM radio and USB/TF card support." },
  { id: "sp8",  name: "CP Karaoke Speaker",             price: 999,  originalPrice: 1999, category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "Mini karaoke speaker with mic input and echo effect." },
  { id: "sp9",  name: "CP Fabric Speaker",              price: 549,  originalPrice: 1099, category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "Fabric-wrapped portable speaker with warm, clear sound." },
  { id: "sp10", name: "CP Soundbar Mini Speaker",       price: 649,  originalPrice: 1299, category: "Electronics", subCategory: "Mini Speakers", image: "/images/speaker.png",   description: "Mini soundbar speaker with optical input and virtual surround." },

  // ── ELECTRONICS: CHARGERS (10 models) ──
  { id: "ch1",  name: "CP 20W Fast Charger",            price: 249,  originalPrice: 499,  category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "PD 20W USB-C fast charger compatible with iPhone and Android." },
  { id: "ch2",  name: "CP Dual Port Charger",           price: 299,  originalPrice: 599,  category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "Dual USB port charger with auto power detect for fast charging." },
  { id: "ch3",  name: "CP 65W GaN Charger",             price: 599,  originalPrice: 1199, category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "GaN technology 65W charger for laptops, tablets, and phones." },
  { id: "ch4",  name: "CP Wireless Charger 15W",        price: 499,  originalPrice: 999,  category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "Qi-certified 15W wireless charging pad for all Qi devices." },
  { id: "ch5",  name: "CP Car Charger",                 price: 199,  originalPrice: 399,  category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "Dual port car charger with 30W fast charge and LED indicator." },
  { id: "ch6",  name: "CP Travel Charger",              price: 349,  originalPrice: 699,  category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "Universal travel charger with international plug adapters." },
  { id: "ch7",  name: "CP 4-Port Charger Hub",          price: 449,  originalPrice: 899,  category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "4-port smart charger hub, charge 4 devices simultaneously." },
  { id: "ch8",  name: "CP Magnetic MagSafe Charger",    price: 399,  originalPrice: 799,  category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "Magnetic snap-on wireless charger for MagSafe-compatible phones." },
  { id: "ch9",  name: "CP Solar Charger",               price: 549,  originalPrice: 1099, category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "Foldable solar panel charger with USB output for outdoor use." },
  { id: "ch10", name: "CP Power Bank 10000mAh",         price: 799,  originalPrice: 1599, category: "Electronics", subCategory: "Chargers",      image: "/images/speaker.png",   description: "10000mAh slim power bank with 22.5W fast charging output." },

  // ── ELECTRONICS: OTG, SanDisk, Memory Cards ──
  { id: "otg1", name: "CP OTG Type-C Adapter",         price: 149,  originalPrice: 299,  category: "Electronics", subCategory: "OTG",           image: "/images/speaker.png",   description: "USB to Type-C OTG adapter for connecting drives to phones." },
  { id: "otg2", name: "CP OTG Micro-USB Adapter",      price: 99,   originalPrice: 199,  category: "Electronics", subCategory: "OTG",           image: "/images/speaker.png",   description: "Micro-USB OTG adapter for older Android phones." },
  { id: "sd1",  name: "SanDisk USB Drive 32GB",        price: 399,  originalPrice: 799,  category: "Electronics", subCategory: "SanDisk",       image: "/images/speaker.png",   description: "High speed SanDisk Ultra USB 3.0 flash drive 32GB." },
  { id: "sd2",  name: "SanDisk USB Drive 64GB",        price: 599,  originalPrice: 1199, category: "Electronics", subCategory: "SanDisk",       image: "/images/speaker.png",   description: "SanDisk Ultra 64GB USB drive with 130MB/s read speed." },
  { id: "mc1",  name: "Memory Card 32GB Class 10",     price: 249,  originalPrice: 499,  category: "Electronics", subCategory: "Memory Cards",  image: "/images/speaker.png",   description: "Class 10 32GB microSD card, ideal for smartphones and cameras." },
  { id: "mc2",  name: "Memory Card 64GB UHS-I",        price: 349,  originalPrice: 699,  category: "Electronics", subCategory: "Memory Cards",  image: "/images/speaker.png",   description: "UHS-I 64GB microSD card with up to 100MB/s read speed." },
  { id: "mc3",  name: "Memory Card 128GB",             price: 599,  originalPrice: 1199, category: "Electronics", subCategory: "Memory Cards",  image: "/images/speaker.png",   description: "128GB microSD card for 4K video recording and large storage." },

  // ── FASHION: WATCHES (10 models) ──
  { id: "w1",   name: "CP Classic Analog Watch",        price: 699,  originalPrice: 1399, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Elegant stainless steel analog watch with leather strap." },
  { id: "w2",   name: "CP Smart Digital Watch",         price: 799,  originalPrice: 1599, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Digital smartwatch with health tracking and notification alerts." },
  { id: "w3",   name: "CP Sport Watch",                 price: 549,  originalPrice: 1099, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Waterproof sports watch with stopwatch and backlight." },
  { id: "w4",   name: "CP Couple Watch Set",            price: 999,  originalPrice: 1999, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Matching couple watch set with rose gold and silver finish." },
  { id: "w5",   name: "CP Skeleton Watch",              price: 899,  originalPrice: 1799, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Skeleton dial mechanical-look watch with transparent face." },
  { id: "w6",   name: "CP Kids Watch",                  price: 349,  originalPrice: 699,  category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Colorful waterproof kids watch with silicone strap." },
  { id: "w7",   name: "CP Luxury Gold Watch",           price: 1299, originalPrice: 1999, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Gold-plated luxury watch with rhinestone dial." },
  { id: "w8",   name: "CP Military Watch",              price: 799,  originalPrice: 1599, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Rugged military-style watch with compass and dual time zone." },
  { id: "w9",   name: "CP Minimalist Watch",            price: 599,  originalPrice: 1199, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Ultra-thin minimalist watch with mesh stainless steel strap." },
  { id: "w10",  name: "CP Chronograph Watch",           price: 1199, originalPrice: 1999, category: "Fashion & Accessories", subCategory: "Watches", image: "/images/watch.png",   description: "Chronograph stopwatch watch with sub-dials and tachymeter bezel." },

  // ── FASHION: PURSES (10 models) ──
  { id: "pu1",  name: "CP Zip Clutch Purse",            price: 399,  originalPrice: 799,  category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Compact zip clutch with card slots and mirror." },
  { id: "pu2",  name: "CP Long Ladies Wallet",          price: 449,  originalPrice: 899,  category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Long ladies wallet with multiple card holders and coin pocket." },
  { id: "pu3",  name: "CP Designer Wristlet",           price: 599,  originalPrice: 1199, category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Stylish designer wristlet with detachable strap." },
  { id: "pu4",  name: "CP Mini Coin Purse",             price: 199,  originalPrice: 399,  category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Cute mini coin purse with zipper closure." },
  { id: "pu5",  name: "CP PU Leather Purse",            price: 499,  originalPrice: 999,  category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Premium PU leather purse with embossed pattern." },
  { id: "pu6",  name: "CP RFID Blocking Purse",         price: 699,  originalPrice: 1399, category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "RFID-blocking secure purse to protect cards from digital theft." },
  { id: "pu7",  name: "CP Canvas Printed Purse",        price: 349,  originalPrice: 699,  category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Trendy canvas purse with floral print design." },
  { id: "pu8",  name: "CP Jute Purse",                  price: 299,  originalPrice: 599,  category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Eco-friendly jute purse with handcrafted design." },
  { id: "pu9",  name: "CP Party Clutch Purse",          price: 549,  originalPrice: 1099, category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Glitter party clutch with chain strap for evening events." },
  { id: "pu10", name: "CP Sling Purse",                 price: 599,  originalPrice: 1199, category: "Fashion & Accessories", subCategory: "Purses", image: "/images/handbag.png", description: "Crossbody sling purse with adjustable strap and zipper pockets." },

  // ── FASHION: COOLING GLASSES (10 models) ──
  { id: "cg1",  name: "CP Aviator Sunglasses",          price: 299,  originalPrice: 599,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Classic aviator sunglasses with UV400 polarized lenses." },
  { id: "cg2",  name: "CP Wayfarer Sunglasses",         price: 349,  originalPrice: 699,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Trendy wayfarer style with thick acetate frame." },
  { id: "cg3",  name: "CP Round Retro Glasses",         price: 249,  originalPrice: 499,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Retro round frame sunglasses with colored tinted lens." },
  { id: "cg4",  name: "CP Sports Wrap Glasses",         price: 399,  originalPrice: 799,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Wrap-around sport sunglasses with anti-glare coating." },
  { id: "cg5",  name: "CP Cat-Eye Sunglasses",          price: 299,  originalPrice: 599,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Trendy cat-eye frame sunglasses for women." },
  { id: "cg6",  name: "CP Square Frame Glasses",        price: 349,  originalPrice: 699,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Bold square frame sunglasses for a strong, modern look." },
  { id: "cg7",  name: "CP Mirror Lens Sunglasses",      price: 299,  originalPrice: 599,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Mirror reflective lens sunglasses, perfect for beach and travel." },
  { id: "cg8",  name: "CP Clip-On Sunglasses",          price: 199,  originalPrice: 399,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Magnetic clip-on sunglasses that attach over prescription frames." },
  { id: "cg9",  name: "CP Blue Light Glasses",          price: 449,  originalPrice: 899,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Blue light blocking glasses for screen time protection." },
  { id: "cg10", name: "CP Night Vision Glasses",        price: 349,  originalPrice: 699,  category: "Fashion & Accessories", subCategory: "Cooling Glasses", image: "/images/sunglasses.png", description: "Yellow lens night-driving glasses to reduce glare." },

  // ── FASHION: HAND BANDS (10 models) ──
  { id: "hb1",  name: "CP Sports Wrist Band",           price: 99,   originalPrice: 199,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Cotton sweat-absorbent sports wrist band, pack of 2." },
  { id: "hb2",  name: "CP Silicon Fitness Band",        price: 149,  originalPrice: 299,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Silicone fitness wrist band with step counter." },
  { id: "hb3",  name: "CP Magnetic Therapy Band",       price: 299,  originalPrice: 599,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Titanium magnetic therapy bracelet for pain relief." },
  { id: "hb4",  name: "CP Beaded Bracelet Band",        price: 199,  originalPrice: 399,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Stylish beaded bracelet hand band, unisex design." },
  { id: "hb5",  name: "CP Leather Wrist Band",          price: 249,  originalPrice: 499,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Genuine leather wrist band with metal clasp, adjustable." },
  { id: "hb6",  name: "CP Power Balance Band",          price: 349,  originalPrice: 699,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Energy balance silicone band with hologram technology." },
  { id: "hb7",  name: "CP Kids Rubber Band",            price: 79,   originalPrice: 159,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Fun colorful rubber wrist bands for kids, set of 5." },
  { id: "hb8",  name: "CP Metal Cuff Band",             price: 299,  originalPrice: 599,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Stainless steel cuff bracelet band, modern minimalist style." },
  { id: "hb9",  name: "CP Paracord Wrist Band",         price: 199,  originalPrice: 399,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "Survival paracord wrist band with compass and whistle." },
  { id: "hb10", name: "CP Anti-Mosquito Band",          price: 149,  originalPrice: 299,  category: "Fashion & Accessories", subCategory: "Hand Bands", image: "/images/watch.png",   description: "DEET-free natural mosquito repellent wrist band." },

  // ── FASHION: HANDBAGS (10 models) ──
  { id: "bag1", name: "CP Tote Handbag",                price: 799,  originalPrice: 1599, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Large tote handbag with zip-top and interior pockets." },
  { id: "bag2", name: "CP Shoulder Handbag",            price: 899,  originalPrice: 1799, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Classic leather shoulder handbag with magnetic snap." },
  { id: "bag3", name: "CP Bucket Bag",                  price: 749,  originalPrice: 1499, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Trendy bucket bag with drawstring top and crossbody strap." },
  { id: "bag4", name: "CP Satchel Bag",                 price: 999,  originalPrice: 1999, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Structured satchel bag with top handle and detachable strap." },
  { id: "bag5", name: "CP Quilted Handbag",             price: 849,  originalPrice: 1699, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Quilted pattern PU leather handbag with gold hardware." },
  { id: "bag6", name: "CP Mini Crossbody Bag",          price: 599,  originalPrice: 1199, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Mini crossbody bag, perfect for daily essentials." },
  { id: "bag7", name: "CP Backpack Handbag",            price: 999,  originalPrice: 1999, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Convertible handbag to backpack with multiple compartments." },
  { id: "bag8", name: "CP Jute Hand Bag",               price: 449,  originalPrice: 899,  category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Eco-friendly jute handbag with printed design." },
  { id: "bag9", name: "CP Glitter Evening Bag",         price: 699,  originalPrice: 1399, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Sparkling glitter evening bag with chain handle." },
  { id: "bag10","name": "CP Office Work Bag",           price: 1199, originalPrice: 1999, category: "Fashion & Accessories", subCategory: "Handbags", image: "/images/handbag.png", description: "Professional office bag with laptop sleeve and organizer." },

  // ── FASHION: SIDE BAGS (10 models) ──
  { id: "sb1",  name: "CP Men Sling Side Bag",          price: 599,  originalPrice: 1199, category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Casual men's sling bag with anti-theft zip pocket." },
  { id: "sb2",  name: "CP Women Crossbody Bag",         price: 699,  originalPrice: 1399, category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Women's crossbody side bag with adjustable strap." },
  { id: "sb3",  name: "CP Canvas Side Bag",             price: 499,  originalPrice: 999,  category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Canvas side bag with front pocket and padded strap." },
  { id: "sb4",  name: "CP Leather Messenger Bag",       price: 899,  originalPrice: 1799, category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Leather messenger side bag with laptop sleeve." },
  { id: "sb5",  name: "CP Hip Pouch Bag",               price: 349,  originalPrice: 699,  category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Bum/hip waist pouch bag for travel and outdoor activities." },
  { id: "sb6",  name: "CP Waterproof Side Bag",         price: 749,  originalPrice: 1499, category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Waterproof side bag with USB charging port cutout." },
  { id: "sb7",  name: "CP Mini Side Pouch",             price: 299,  originalPrice: 599,  category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Mini side pouch bag for phone, keys, and cards." },
  { id: "sb8",  name: "CP Denim Side Bag",              price: 449,  originalPrice: 899,  category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Trendy denim fabric side bag with patch design." },
  { id: "sb9",  name: "CP Sports Side Bag",             price: 549,  originalPrice: 1099, category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Sports side bag with reflective strips for night safety." },
  { id: "sb10", name: "CP Travel Side Bag",             price: 799,  originalPrice: 1599, category: "Fashion & Accessories", subCategory: "Side Bags", image: "/images/handbag.png", description: "Multi-compartment travel side bag with luggage strap sleeve." },

  // ── FASHION: SCHOOL BAGS (10 models) ──
  { id: "sc1",  name: "CP Primary School Bag",          price: 699,  originalPrice: 1399, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Lightweight primary school bag with cartoon print." },
  { id: "sc2",  name: "CP High School Backpack",        price: 999,  originalPrice: 1999, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Ergonomic high school backpack with laptop pocket." },
  { id: "sc3",  name: "CP Waterproof School Bag",       price: 1099, originalPrice: 1999, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Waterproof school bag with USB charging port." },
  { id: "sc4",  name: "CP Sports School Bag",           price: 799,  originalPrice: 1599, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Multi-pocket sports school bag with shoe compartment." },
  { id: "sc5",  name: "CP Princess Girls Bag",          price: 749,  originalPrice: 1499, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Cute princess-themed school bag with sequin design for girls." },
  { id: "sc6",  name: "CP Boys Hero Bag",               price: 749,  originalPrice: 1499, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Boys superhero print school bag with reflective strip." },
  { id: "sc7",  name: "CP College Campus Bag",          price: 1199, originalPrice: 1999, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Large college bag with organizer front pocket and 15.6\" laptop sleeve." },
  { id: "sc8",  name: "CP Trolley School Bag",          price: 1499, originalPrice: 1999, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Trolley wheel school bag to reduce backpack strain." },
  { id: "sc9",  name: "CP Mini Daypack",                price: 549,  originalPrice: 1099, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Small daypack for daily school essentials." },
  { id: "sc10", name: "CP Premium Leather School Bag",  price: 1799, originalPrice: 1999, category: "Fashion & Accessories", subCategory: "School Bags", image: "/images/handbag.png", description: "Premium PU leather school bag with padded back support." },

  // ── FASHION: JERSEYS (10 models) ──
  { id: "jr1",  name: "CP Football Jersey",             price: 499,  originalPrice: 999,  category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Breathable polyester football jersey with number print." },
  { id: "jr2",  name: "CP Cricket Jersey",              price: 549,  originalPrice: 1099, category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Sublimation printed cricket jersey, dry-fit fabric." },
  { id: "jr3",  name: "CP Basketball Jersey Set",       price: 699,  originalPrice: 1399, category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Basketball jersey and shorts set with mesh fabric." },
  { id: "jr4",  name: "CP Club Soccer Jersey",          price: 599,  originalPrice: 1199, category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Club-style soccer jersey with custom number option." },
  { id: "jr5",  name: "CP Polo T-Shirt Jersey",         price: 399,  originalPrice: 799,  category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Classic polo collar jersey for casual and sports wear." },
  { id: "jr6",  name: "CP Athletic Running Jersey",     price: 449,  originalPrice: 899,  category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Lightweight running jersey with sweat-wicking technology." },
  { id: "jr7",  name: "CP Cycling Jersey",              price: 699,  originalPrice: 1399, category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Tight-fit cycling jersey with rear pockets and UV protection." },
  { id: "jr8",  name: "CP Team Name Jersey",            price: 599,  originalPrice: 1199, category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Customizable team jersey with name and number on back." },
  { id: "jr9",  name: "CP Compression Jersey",         price: 749,  originalPrice: 1499, category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Compression sports jersey for muscle support during workouts." },
  { id: "jr10", name: "CP Kids Sports Jersey",          price: 349,  originalPrice: 699,  category: "Fashion & Accessories", subCategory: "Jerseys", image: "/images/shoes.png",    description: "Kids sports jersey with fun color block design." },

  // ── FOOTWEAR: SHOES (10 models) ──
  { id: "sh1",  name: "CP Running Sneakers",            price: 799,  originalPrice: 1599, category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Lightweight running sneakers with cushioned insole." },
  { id: "sh2",  name: "CP Casual Canvas Shoes",         price: 599,  originalPrice: 1199, category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Classic canvas shoes for everyday casual wear." },
  { id: "sh3",  name: "CP Formal Leather Shoes",        price: 999,  originalPrice: 1999, category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Elegant formal leather shoes for office and events." },
  { id: "sh4",  name: "CP Sports Basketball Shoes",     price: 1199, originalPrice: 1999, category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "High-ankle basketball shoes with anti-slip sole." },
  { id: "sh5",  name: "CP Loafers",                     price: 699,  originalPrice: 1399, category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Slip-on loafers with comfort memory foam insole." },
  { id: "sh6",  name: "CP Girls Fashion Shoes",         price: 599,  originalPrice: 1199, category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Trendy fashion shoes for girls with bow decoration." },
  { id: "sh7",  name: "CP Trekking Shoes",              price: 1299, originalPrice: 1999, category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Waterproof trekking shoes with high-grip rubber sole." },
  { id: "sh8",  name: "CP School Shoes",                price: 499,  originalPrice: 999,  category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Durable black school shoes with anti-skid sole." },
  { id: "sh9",  name: "CP Flip Flop Sneakers",          price: 449,  originalPrice: 899,  category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Hybrid sneaker with easy flip-flop style closure." },
  { id: "sh10", name: "CP Boots",                       price: 1499, originalPrice: 1999, category: "Footwear", subCategory: "Shoes", image: "/images/shoes.png",    description: "Ankle boots with side zip and slip-resistant sole." },

  // ── FOOTWEAR: CHAPPALS (10 models) ──
  { id: "cl1",  name: "CP Daily Wear Slippers",         price: 199,  originalPrice: 399,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Soft EVA daily wear slippers for home and outdoor." },
  { id: "cl2",  name: "CP Rubber Chappal",              price: 249,  originalPrice: 499,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Durable rubber chappal with anti-skid sole." },
  { id: "cl3",  name: "CP Ladies Flat Sandal",          price: 349,  originalPrice: 699,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Stylish flat sandal for women with embellishment." },
  { id: "cl4",  name: "CP Men's Sandal",                price: 399,  originalPrice: 799,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Men's cushioned sandal with velcro strap and arch support." },
  { id: "cl5",  name: "CP Kolhapuri Chappal",           price: 449,  originalPrice: 899,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Traditional Kolhapuri style handcrafted leather chappal." },
  { id: "cl6",  name: "CP Printed Chappal",             price: 299,  originalPrice: 599,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Colorful printed chappal with padded footbed." },
  { id: "cl7",  name: "CP Flip Flops",                  price: 149,  originalPrice: 299,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Classic Y-strap flip flops, lightweight and comfortable." },
  { id: "cl8",  name: "CP Wedge Sandal",                price: 499,  originalPrice: 999,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Ladies wedge sandal with ankle strap for extra style." },
  { id: "cl9",  name: "CP Sports Sandal",               price: 449,  originalPrice: 899,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Outdoor sports sandal with adjustable straps and grip sole." },
  { id: "cl10", name: "CP Kids Chappal",                price: 199,  originalPrice: 399,  category: "Footwear", subCategory: "Chappals", image: "/images/shoes.png",    description: "Cute lightweight chappal for kids with velcro strap." },

  // ── MOBILE GADGETS: PHONE CASES (10 models) ──
  { id: "pc1",  name: "CP Clear Shockproof Case",       price: 149,  originalPrice: 299,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Transparent shockproof TPU phone case with corner protection." },
  { id: "pc2",  name: "CP Leather Wallet Case",         price: 299,  originalPrice: 599,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Leather wallet case with card slots and kickstand." },
  { id: "pc3",  name: "CP Armor Case",                  price: 199,  originalPrice: 399,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Heavy-duty armor case with dual layer drop protection." },
  { id: "pc4",  name: "CP Silicone Soft Case",          price: 99,   originalPrice: 199,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Soft silicone case with microfiber lining, anti-fingerprint." },
  { id: "pc5",  name: "CP Glitter Sparkle Case",        price: 149,  originalPrice: 299,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Glitter liquid quicksand phone case with sparkle effect." },
  { id: "pc6",  name: "CP Magnetic Slim Case",          price: 249,  originalPrice: 499,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Slim magnetic case compatible with MagSafe accessories." },
  { id: "pc7",  name: "CP Printed Designer Case",       price: 179,  originalPrice: 359,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Printed designer case with vibrant artwork, multiple designs." },
  { id: "pc8",  name: "CP Ring Holder Case",            price: 199,  originalPrice: 399,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Phone case with 360° rotating ring holder for grip and stand." },
  { id: "pc9",  name: "CP Carbon Fiber Case",           price: 249,  originalPrice: 499,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Carbon fiber textured slim case with metal buttons." },
  { id: "pc10", name: "CP Waterproof Case",             price: 349,  originalPrice: 699,  category: "Mobile Gadgets", subCategory: "Phone Cases", image: "/images/phone-case.png", description: "Fully waterproof IP68 phone case for underwater use." },

  // ── MOBILE GADGETS: PHONE STANDS (10 models) ──
  { id: "ps1",  name: "CP Adjustable Desk Stand",       price: 249,  originalPrice: 499,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Adjustable aluminum phone stand for desk, holds all phones." },
  { id: "ps2",  name: "CP Foldable Pocket Stand",       price: 149,  originalPrice: 299,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Ultra-thin foldable phone stand fits in wallet." },
  { id: "ps3",  name: "CP Gooseneck Flexible Stand",    price: 299,  originalPrice: 599,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Gooseneck flexible arm phone stand for bed and desk." },
  { id: "ps4",  name: "CP Car Dashboard Stand",         price: 199,  originalPrice: 399,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Suction cup car dashboard phone stand with one-touch release." },
  { id: "ps5",  name: "CP Wireless Charging Stand",     price: 499,  originalPrice: 999,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "10W wireless charging phone stand with angle adjustment." },
  { id: "ps6",  name: "CP Ring Light Stand",            price: 349,  originalPrice: 699,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Phone stand with LED ring light for selfies and video calls." },
  { id: "ps7",  name: "CP Clip Stand for Bed",          price: 199,  originalPrice: 399,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Lazy bed clip stand for hands-free phone viewing." },
  { id: "ps8",  name: "CP Multi-Angle Stand",           price: 179,  originalPrice: 359,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Foldable multi-angle stand supports 0-90° viewing angles." },
  { id: "ps9",  name: "CP Tripod Phone Stand",          price: 349,  originalPrice: 699,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Mini tripod phone stand for photography and video." },
  { id: "ps10", name: "CP Tablet & Phone Stand",        price: 299,  originalPrice: 599,  category: "Mobile Gadgets", subCategory: "Phone Stands", image: "/images/phone-case.png", description: "Universal stand for both phones and tablets up to 13 inch." },

  // ── MOBILE GADGETS: FINGER COVERS (10 models) ──
  { id: "fc1",  name: "CP Anti-Sweat Finger Cover",     price: 99,   originalPrice: 199,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Anti-sweat silicone finger cover for gaming, pack of 6." },
  { id: "fc2",  name: "CP Copper Finger Cover",         price: 129,  originalPrice: 259,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Conductive copper fiber finger cover for touch screen gaming." },
  { id: "fc3",  name: "CP Lycra Gaming Finger Sleeve",  price: 149,  originalPrice: 299,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Breathable lycra finger sleeve for sweat-free mobile gaming." },
  { id: "fc4",  name: "CP Ultra-Thin Finger Cover",     price: 79,   originalPrice: 159,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Ultra-thin finger cover for precise touch sensitivity." },
  { id: "fc5",  name: "CP Pro Gaming Finger Set",       price: 199,  originalPrice: 399,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Pro gaming 10-piece finger cover set with carry pouch." },
  { id: "fc6",  name: "CP Ring Holder Finger Cover",    price: 149,  originalPrice: 299,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Finger cover with 360° ring holder for secure phone grip." },
  { id: "fc7",  name: "CP Silicone Neon Finger Cover",  price: 99,   originalPrice: 199,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Neon colored silicone finger covers, pack of 8." },
  { id: "fc8",  name: "CP Anti-Blue Light Cover",       price: 179,  originalPrice: 359,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Anti-blue light finger cover to protect fingers during long gaming." },
  { id: "fc9",  name: "CP Touchscreen Glove Tips",      price: 129,  originalPrice: 259,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Touchscreen-compatible glove tips for cold weather use." },
  { id: "fc10", name: "CP Thumb Finger Cover Set",      price: 149,  originalPrice: 299,  category: "Mobile Gadgets", subCategory: "Finger Covers", image: "/images/phone-case.png", description: "Thumb-specific finger covers for PUBG and Free Fire gaming." },
];

export const categories = ["All", "Electronics", "Fashion & Accessories", "Footwear", "Mobile Gadgets"] as const;
export type Category = typeof categories[number];

export const subCategories: Record<string, string[]> = {
  "Electronics": ["Earpods", "Earphones", "Headsets", "Mini Speakers", "Chargers", "OTG", "SanDisk", "Memory Cards"],
  "Fashion & Accessories": ["Watches", "Purses", "Cooling Glasses", "Hand Bands", "Handbags", "Side Bags", "School Bags", "Jerseys"],
  "Footwear": ["Shoes", "Chappals"],
  "Mobile Gadgets": ["Phone Cases", "Phone Stands", "Finger Covers"],
};
