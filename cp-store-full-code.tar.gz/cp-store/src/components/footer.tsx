import { SiWhatsapp, SiInstagram } from "react-icons/si";
import { Phone, Mail, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 pt-12 pb-6 mt-16 border-t-4 border-primary">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-primary text-white font-black text-xl px-2 py-1 rounded shadow-sm leading-none tracking-tighter italic">CP</div>
              <span className="text-white font-bold text-lg tracking-tight">STORE</span>
            </div>
            <p className="text-sm text-gray-400 mb-4">
              Your trusted destination for affordable electronics, fashion, footwear, and mobile accessories. Quality products under ₹2000.
            </p>
            <div className="flex gap-4">
              <a href="https://wa.me/917907303634" target="_blank" rel="noreferrer" className="text-gray-400 hover:text-green-400 transition-colors">
                <SiWhatsapp size={24} />
              </a>
              <a href="https://instagram.com/muhammedcp_" target="_blank" rel="noreferrer" className="text-gray-400 hover:text-pink-400 transition-colors">
                <SiInstagram size={22} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-white font-bold text-lg mb-4 uppercase tracking-wider">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Phone size={18} className="text-primary shrink-0 mt-0.5" />
                <span>+91 7907 303634</span>
              </li>
              <li className="flex items-start gap-3">
                <SiWhatsapp size={18} className="text-green-500 shrink-0 mt-0.5" />
                <a href="https://wa.me/917907303634" className="hover:text-white transition-colors">Chat on WhatsApp</a>
              </li>
              <li className="flex items-start gap-3">
                <SiInstagram size={18} className="text-pink-500 shrink-0 mt-0.5" />
                <a href="https://instagram.com/muhammedcp_" className="hover:text-white transition-colors">@muhammedcp_</a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-bold text-lg mb-4 uppercase tracking-wider">Delivery Information</h3>
            <div className="bg-gray-800 p-4 rounded-lg border border-gray-700">
              <p className="text-sm mb-2 text-gray-300">
                <strong className="text-white">Fast Courier Delivery</strong>
              </p>
              <p className="text-sm text-gray-400 mb-3">
                Delivered safely via Professional Courier within 3-5 working days anywhere in India.
              </p>
              <div className="flex items-center gap-2 text-accent text-sm font-bold">
                <span className="w-2 h-2 rounded-full bg-accent"></span>
                100% Secure Payment
              </div>
            </div>
          </div>

        </div>

        <div className="border-t border-gray-800 pt-6 text-center text-sm text-gray-500">
          <p>&copy; {new Date().getFullYear()} CP Store. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
