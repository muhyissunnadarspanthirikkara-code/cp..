import { Link } from "wouter";
import { Phone, Search, ShoppingCart } from "lucide-react";
import { SiWhatsapp, SiInstagram } from "react-icons/si";

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full bg-primary shadow-md">
      {/* Top Banner */}
      <div className="bg-primary/90 text-primary-foreground text-xs py-1 px-4 text-center font-medium flex justify-center items-center gap-2">
        <span>Fast Delivery | 100% Secure Payment | Call/WhatsApp:</span>
        <a href="https://wa.me/917907303634" className="font-bold hover:underline" target="_blank" rel="noreferrer">+91 7907 303634</a>
      </div>

      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4 flex-wrap sm:flex-nowrap">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <img src="/images/cp-logo.png" alt="CP Store" className="h-10 w-auto bg-white rounded px-1 shadow-sm" />
          </Link>

          {/* Search Bar */}
          <div className="flex-1 max-w-2xl w-full order-last sm:order-none">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search for products, brands and more" 
                className="w-full bg-white text-black pl-4 pr-10 py-2 rounded-sm border-none focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <button className="absolute right-0 top-0 bottom-0 px-3 text-primary flex items-center justify-center bg-white rounded-r-sm">
                <Search size={18} />
              </button>
            </div>
          </div>

          {/* Contact & Actions */}
          <div className="flex items-center gap-3 sm:gap-5 shrink-0">
            <a href="tel:+917907303634" className="text-white hover:text-white/80 transition-colors flex items-center gap-1">
              <Phone size={20} />
              <span className="hidden lg:block text-sm font-medium">Call Us</span>
            </a>
            <a href="https://wa.me/917907303634" target="_blank" rel="noreferrer" className="text-green-400 hover:text-green-300 transition-colors bg-white/10 p-1.5 rounded-full">
              <SiWhatsapp size={20} />
            </a>
            <a href="https://instagram.com/muhammedcp_" target="_blank" rel="noreferrer" className="text-pink-400 hover:text-pink-300 transition-colors bg-white/10 p-1.5 rounded-full">
              <SiInstagram size={18} />
            </a>
            <Link href="/" className="text-white hover:text-white/80 transition-colors flex items-center gap-1 pl-2 border-l border-white/20">
              <ShoppingCart size={22} />
              <span className="hidden sm:block text-sm font-bold">Cart</span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}
