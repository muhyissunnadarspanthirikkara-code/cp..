import { useParams, Link } from "wouter";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { products } from "@/data/products";
import { ShieldCheck, Truck, Check, ArrowLeft } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";

export default function ProductDetail() {
  const params = useParams();
  const product = products.find(p => p.id === params.id);

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header />
        <main className="flex-1 flex flex-col items-center justify-center p-4">
          <h2 className="text-2xl font-bold mb-4">Product Not Found</h2>
          <Link href="/" className="text-primary hover:underline">Return to Home</Link>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />

      <main className="flex-1">
        <div className="container mx-auto px-4 py-6">
          <Link href="/" className="inline-flex items-center gap-2 text-sm text-gray-600 hover:text-primary mb-6">
            <ArrowLeft size={16} /> Back to Products
          </Link>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex flex-col md:flex-row">
            
            {/* Image Section */}
            <div className="md:w-1/2 p-8 bg-white flex items-center justify-center border-b md:border-b-0 md:border-r border-gray-200">
              <img 
                src={product.image} 
                alt={product.name} 
                className="max-w-full max-h-[400px] object-contain"
              />
            </div>

            {/* Details Section */}
            <div className="md:w-1/2 p-6 md:p-8 flex flex-col">
              <div className="mb-2">
                <span className="text-sm font-semibold text-primary tracking-wider uppercase">{product.category}</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">{product.name}</h1>
              
              <div className="flex items-end gap-3 mb-6">
                <span className="text-4xl font-black text-gray-900">₹{product.price}</span>
                <span className="text-lg text-gray-500 line-through mb-1">₹{product.originalPrice}</span>
                <span className="text-sm font-bold text-green-600 mb-1.5 ml-2 bg-green-100 px-2 py-0.5 rounded">
                  {Math.round((1 - product.price / product.originalPrice) * 100)}% off
                </span>
              </div>

              <div className="border-t border-b border-gray-100 py-4 mb-6">
                <h3 className="font-bold text-gray-900 mb-2">Product Description</h3>
                <p className="text-gray-600 text-sm leading-relaxed">{product.description}</p>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-3">
                  <div className="bg-green-100 p-1.5 rounded-full text-green-600 shrink-0">
                    <Check size={16} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-900">In Stock & Ready to Ship</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-blue-100 p-1.5 rounded-full text-blue-600 shrink-0">
                    <Truck size={16} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-900">Fast Delivery</p>
                    <p className="text-xs text-gray-500">Delivered safely via Professional Courier within 3-5 working days.</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="bg-orange-100 p-1.5 rounded-full text-accent shrink-0">
                    <ShieldCheck size={16} />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-900">100% Secure Payment</p>
                    <p className="text-xs text-gray-500">Verified and trusted transactions.</p>
                  </div>
                </div>
              </div>

              <div className="mt-auto flex flex-col gap-3">
                <Link 
                  href={`/payment?product=${product.id}`}
                  className="w-full bg-accent hover:bg-accent/90 text-white font-bold py-3.5 px-6 rounded-sm text-center transition-colors uppercase tracking-wider shadow-sm flex items-center justify-center gap-2"
                >
                  Buy Now
                </Link>
                
                <a 
                  href={`https://wa.me/917907303634?text=Hi, I want to inquire about ${product.name} (₹${product.price})`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold py-3.5 px-6 rounded-sm text-center transition-colors uppercase tracking-wider shadow-sm flex items-center justify-center gap-2"
                >
                  <SiWhatsapp size={20} /> Chat on WhatsApp
                </a>
              </div>
              
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
