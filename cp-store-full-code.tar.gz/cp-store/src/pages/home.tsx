import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { products, subCategories } from "@/data/products";
import { ShieldCheck, Truck, Clock, MessageCircle, ChevronRight } from "lucide-react";

export default function Home() {
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [activeSubCategory, setActiveSubCategory] = useState<string>("All");

  const categories = ["All", "Electronics", "Fashion & Accessories", "Footwear", "Mobile Gadgets"];

  const currentSubCategories = activeCategory !== "All" ? subCategories[activeCategory] ?? [] : [];

  const filteredProducts = useMemo(() => {
    let list = activeCategory === "All" ? products : products.filter(p => p.category === activeCategory);
    if (activeSubCategory !== "All" && activeSubCategory !== "") {
      list = list.filter(p => p.subCategory === activeSubCategory);
    }
    return list;
  }, [activeCategory, activeSubCategory]);

  function handleCategoryClick(cat: string) {
    setActiveCategory(cat);
    setActiveSubCategory("All");
  }

  return (
    <div className="min-h-screen bg-[#f0f4ff] flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Trust Badges Banner */}
        <div className="bg-white border-b border-gray-200 py-3 overflow-x-auto shadow-sm">
          <div className="container mx-auto px-4 flex justify-between items-center gap-6 min-w-max">
            <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
              <ShieldCheck className="text-[#ff6000]" size={20} />
              100% Secure Payment
            </div>
            <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
              <Truck className="text-[#ff6000]" size={20} />
              Fast Courier Delivery
            </div>
            <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
              <Clock className="text-[#ff6000]" size={20} />
              3-5 Day Delivery
            </div>
            <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
              <MessageCircle className="text-[#ff6000]" size={20} />
              WhatsApp Order Support
            </div>
          </div>
        </div>

        {/* Main Categories */}
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="container mx-auto px-4">
            <div className="flex overflow-x-auto gap-0 hide-scrollbar">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => handleCategoryClick(cat)}
                  className={`whitespace-nowrap px-5 py-4 text-sm font-semibold transition-all border-b-2 ${
                    activeCategory === cat
                      ? "border-[#1a56db] text-[#1a56db]"
                      : "border-transparent text-gray-600 hover:text-[#1a56db] hover:border-[#1a56db]/40"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Sub-Category Filter (shown when a category is selected) */}
        {currentSubCategories.length > 0 && (
          <div className="bg-[#f7f8ff] border-b border-gray-200">
            <div className="container mx-auto px-4 py-3">
              <div className="flex items-center gap-2 overflow-x-auto pb-1 hide-scrollbar">
                <ChevronRight size={14} className="text-gray-400 shrink-0" />
                <button
                  onClick={() => setActiveSubCategory("All")}
                  className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
                    activeSubCategory === "All"
                      ? "bg-[#1a56db] text-white shadow"
                      : "bg-white text-gray-600 border border-gray-200 hover:border-[#1a56db] hover:text-[#1a56db]"
                  }`}
                >
                  All
                </button>
                {currentSubCategories.map((sub) => (
                  <button
                    key={sub}
                    onClick={() => setActiveSubCategory(sub)}
                    className={`whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-semibold transition-all ${
                      activeSubCategory === sub
                        ? "bg-[#1a56db] text-white shadow"
                        : "bg-white text-gray-600 border border-gray-200 hover:border-[#1a56db] hover:text-[#1a56db]"
                    }`}
                  >
                    {sub}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Hero Banner */}
        {activeCategory === "All" && (
          <div className="container mx-auto px-4 pt-6 pb-2">
            <div className="bg-gradient-to-r from-[#1a56db] to-[#1e40af] rounded-xl shadow-lg overflow-hidden flex flex-col md:flex-row text-white">
              <div className="p-8 md:p-12 flex-1 flex flex-col justify-center">
                <span className="bg-[#ff6000] text-white text-xs font-bold px-3 py-1 rounded-full w-max mb-4 uppercase tracking-wider">Mega Deals</span>
                <h2 className="text-3xl md:text-5xl font-black mb-4 leading-tight">
                  All Quality Products <br />Under <span className="text-[#ff6000]">₹2000</span>
                </h2>
                <p className="text-blue-100 mb-6 max-w-md">
                  Electronics, Fashion, Footwear & Gadgets — all at unbeatable prices with fast delivery.
                </p>
                <div className="flex flex-wrap gap-3">
                  <button onClick={() => handleCategoryClick("Electronics")} className="bg-white text-[#1a56db] font-bold py-2 px-6 rounded-sm shadow-md hover:bg-gray-100 transition-colors text-sm">
                    Shop Electronics
                  </button>
                  <button onClick={() => handleCategoryClick("Fashion & Accessories")} className="bg-[#ff6000] text-white font-bold py-2 px-6 rounded-sm shadow-md hover:bg-[#e05500] transition-colors text-sm">
                    Shop Fashion
                  </button>
                </div>
              </div>
              <div className="hidden md:flex flex-1 relative bg-blue-800/40 p-6 items-center justify-center">
                <div className="grid grid-cols-2 gap-4 w-full max-w-sm">
                  <div className="rounded-lg shadow-md bg-white aspect-square flex items-center justify-center p-3">
                    <img src="/images/earpods.png" alt="Earpods" className="object-contain max-h-full" />
                  </div>
                  <div className="rounded-lg shadow-md bg-white aspect-square flex items-center justify-center p-3">
                    <img src="/images/watch.png" alt="Watch" className="object-contain max-h-full" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Product Grid */}
        <div className="container mx-auto px-4 py-6 pb-16">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-lg font-bold text-gray-900 inline-block border-b-2 border-[#1a56db] pb-1 pr-4">
                {activeSubCategory !== "All" && activeSubCategory !== "" ? activeSubCategory : activeCategory === "All" ? "All Products" : activeCategory}
              </h2>
            </div>
            <span className="text-sm text-gray-500 font-medium bg-white border border-gray-200 rounded-full px-3 py-1">
              {filteredProducts.length} Items
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
            {filteredProducts.map((product) => (
              <Link
                key={product.id}
                href={`/product/${product.id}`}
                className="group bg-white rounded-md border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-all flex flex-col h-full hover:-translate-y-0.5"
              >
                <div className="aspect-square bg-white p-4 relative overflow-hidden flex items-center justify-center">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="object-contain max-h-full max-w-full group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 left-2 bg-green-100 text-green-700 text-[10px] font-bold px-2 py-0.5 rounded">In Stock</div>
                  {product.originalPrice > product.price && (
                    <div className="absolute top-2 right-2 bg-[#ff6000] text-white text-[10px] font-bold px-2 py-0.5 rounded">
                      {Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
                    </div>
                  )}
                </div>
                <div className="p-3 flex flex-col flex-1 border-t border-gray-100">
                  <span className="text-[10px] text-[#1a56db] font-semibold mb-1 uppercase tracking-wide">{product.subCategory}</span>
                  <h3 className="text-sm font-medium text-gray-800 line-clamp-2 mb-2 flex-1 group-hover:text-[#1a56db] transition-colors">
                    {product.name}
                  </h3>
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-base font-bold text-gray-900">₹{product.price}</span>
                    <span className="text-xs text-gray-400 line-through">₹{product.originalPrice}</span>
                  </div>
                </div>
                <div className="px-3 pb-3">
                  <button className="w-full bg-[#ff6000] hover:bg-[#e05500] text-white font-bold py-2 rounded-sm text-xs transition-colors uppercase tracking-wide">
                    Buy Now
                  </button>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
