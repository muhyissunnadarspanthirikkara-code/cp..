import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { products } from "@/data/products";
import { SiWhatsapp } from "react-icons/si";
import { ShieldCheck, Truck, Lock, ArrowLeft, Copy, Check } from "lucide-react";

export default function PaymentPage() {
  const [location] = useLocation();
  const [copied, setCopied] = useState(false);
  const upiId = "cp@okaxis";
  
  // Extract product ID from query params manually since we don't have useSearchParams
  const searchParams = new URLSearchParams(window.location.search);
  const productId = searchParams.get("product");
  const product = products.find(p => p.id === productId);

  const handleCopy = () => {
    navigator.clipboard.writeText(upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col">
        <Header />
        <main className="flex-1 flex flex-col items-center justify-center p-4">
          <h2 className="text-2xl font-bold mb-4">No Product Selected</h2>
          <Link href="/" className="text-primary hover:underline">Return to Home</Link>
        </main>
        <Footer />
      </div>
    );
  }

  const whatsappMessage = encodeURIComponent(
    `Hi CP Store! I'd like to confirm my order.\n\n*Order Details:*\nProduct: ${product.name}\nPrice: ₹${product.price}\n\nI have attached the payment screenshot.`
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />

      <main className="flex-1 py-8">
        <div className="container mx-auto px-4 max-w-4xl">
          
          <div className="flex items-center justify-center gap-2 mb-8">
            <Lock className="text-green-600" size={24} />
            <h1 className="text-2xl md:text-3xl font-black text-gray-900">Secure Checkout</h1>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            
            {/* Left Col: Order Summary & Delivery */}
            <div className="flex-1 flex flex-col gap-6">
              
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3 mb-4">Order Summary</h2>
                
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-20 h-20 bg-gray-50 rounded border border-gray-100 p-1 flex items-center justify-center">
                    <img src={product.image} alt={product.name} className="max-w-full max-h-full object-contain" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-gray-800">{product.name}</h3>
                    <p className="text-sm text-gray-500">{product.category}</p>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-lg text-gray-900">₹{product.price}</span>
                  </div>
                </div>

                <div className="border-t border-gray-100 pt-4 mt-2">
                  <div className="flex justify-between text-sm mb-2 text-gray-600">
                    <span>Subtotal</span>
                    <span>₹{product.price}</span>
                  </div>
                  <div className="flex justify-between text-sm mb-2 text-gray-600">
                    <span>Delivery Charges</span>
                    <span className="text-green-600 font-bold">FREE</span>
                  </div>
                  <div className="flex justify-between font-black text-lg mt-4 pt-4 border-t border-gray-100 text-gray-900">
                    <span>Total Amount</span>
                    <span>₹{product.price}</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h2 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-3 mb-4 flex items-center gap-2">
                  <Truck size={20} className="text-primary" /> Delivery Information
                </h2>
                <p className="text-gray-600 text-sm leading-relaxed">
                  Your products will be safely delivered via <strong>Professional Courier</strong> service within <strong>3-5 working days</strong> to your doorstep.
                </p>
                <div className="mt-4 flex items-center gap-2 text-sm text-green-700 bg-green-50 p-3 rounded border border-green-100">
                  <ShieldCheck size={18} />
                  <span>100% Assured Delivery Quality</span>
                </div>
              </div>

              <Link href={`/product/${product.id}`} className="text-sm font-medium text-primary hover:underline flex items-center gap-1 w-max">
                <ArrowLeft size={16} /> Edit Order
              </Link>
            </div>

            {/* Right Col: Payment Action */}
            <div className="flex-1 lg:max-w-md">
              <div className="bg-white rounded-lg shadow-md border-t-4 border-primary p-6 md:p-8 text-center sticky top-24">
                
                <h2 className="text-xl font-bold text-gray-900 mb-2">Scan & Pay via GPay / UPI</h2>
                <p className="text-sm text-gray-500 mb-6">Scan the QR code below using any UPI app</p>
                
                <div className="bg-gray-50 border border-gray-200 p-4 rounded-xl inline-block mb-6 shadow-inner">
                  <img 
                    src="/images/gpay-qr.png" 
                    alt="Scan to pay" 
                    className="w-48 h-48 object-cover rounded-lg"
                  />
                  <div className="mt-3 font-medium text-gray-700 tracking-wider">
                    Amount: <span className="font-black text-xl text-gray-900">₹{product.price}</span>
                  </div>
                </div>

                <div className="mb-6">
                  <p className="text-xs text-gray-500 uppercase tracking-wider font-bold mb-2">Or Pay to UPI ID</p>
                  <div className="flex items-center justify-center gap-0 max-w-[250px] mx-auto">
                    <div className="bg-gray-100 border border-gray-300 rounded-l-md px-4 py-2 text-gray-800 font-mono text-sm flex-1 truncate">
                      {upiId}
                    </div>
                    <button 
                      onClick={handleCopy}
                      className="bg-gray-200 hover:bg-gray-300 border border-l-0 border-gray-300 rounded-r-md px-3 py-2 text-gray-700 transition-colors flex items-center justify-center"
                      title="Copy UPI ID"
                    >
                      {copied ? <Check size={16} className="text-green-600" /> : <Copy size={16} />}
                    </button>
                  </div>
                </div>

                <div className="bg-orange-50 border border-orange-200 rounded-md p-4 mb-6">
                  <p className="text-accent font-bold text-sm leading-relaxed">
                    🚨 IMPORTANT STEP: Please send a screenshot of the successful payment to our WhatsApp for order confirmation.
                  </p>
                </div>

                <a 
                  href={`https://wa.me/917907303634?text=${whatsappMessage}`}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold py-4 px-6 rounded-md text-center transition-colors shadow-md flex items-center justify-center gap-3 text-lg"
                >
                  <SiWhatsapp size={24} /> 
                  Send Payment Proof
                </a>

                <p className="text-xs text-gray-400 mt-4 text-center">
                  By paying, you agree to our terms and conditions.
                </p>
              </div>
            </div>

          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
